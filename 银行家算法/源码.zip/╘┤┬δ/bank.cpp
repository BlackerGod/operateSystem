#include <stdio.h>
#define MAXprocess 50                            //最大进程数
#define MAXresource 100                          //最大资源数
int Available[MAXresource];                      //可用资源数组
int Work[MAXresource];                           //工作向量
int ShowWork[MAXprocess][MAXresource];           //Show工作向量
int Max[MAXprocess][MAXresource];                //进程最大需求资源数组
int Allocation[MAXprocess][MAXresource];         //进程分配资源数组
int Need[MAXprocess][MAXresource];               //进程需求资源数组
int Request[MAXprocess][MAXresource];            //进程请求资源数组
bool Finish[MAXprocess];                         //系统是否有足够的资源分配
int p[MAXprocess];                               //记录序列
int process, resource;                           //process个进程,resource个资源

void Print(){
	printf("\n******************************************************\n");
	printf("**                   1.资源信息初始化               **\n");
	printf("**                   2.显示资源信息                 **\n");
	printf("**                   3.安全性检测                   **\n");
	printf("**                   4.进程申请资源                 **\n");
	printf("**                   5.退出                         **\n");
	printf("******************************************************\n");
	printf("请输入您的操作：");
}
void Input(){
	int i, j;
	printf("请输入进程的数目：");
	scanf_s("%d", &process);
	printf("请输入资源的种类：");
	scanf_s("%d", &resource);
	for (i = 0; i < process; i++){
		printf("请输入第 %d 个进程最大所需的各资源数：", i + 1);
		for (j = 0; j < resource; j++){
			scanf_s("%d",&Max[i][j]);
		}
	}
	for (i = 0; i < process; i++){
		printf("请输入第 %d 个进程已分配的各资源数：", i + 1);
		for (j = 0; j < resource; j++){
			scanf_s("%d", &Allocation[i][j]);
		}
	}
	for (i = 0; i < resource; i++){
		printf("请输入第 %d 类资源的总数：", i + 1);
		scanf_s("%d", &Available[i]);
	}
	for (i = 0; i < process; i++){
		for (j = 0; j < resource; j++){
			Available[j] -= Allocation[i][j];
		}
	}
	for (i = 0; i < process; i++){
		for (j = 0; j < resource; j++){
			Need[i][j] = Max[i][j] - Allocation[i][j];
		}
	}
}
void ShowResource(){
	int i, j;
	printf("\n             Max              Allocation         Need             Available\n");
	printf("          ");
	for (j = 0; j < resource; j++){
		printf("%3d类", j + 1);
	}
	printf("        ");
	for (j = 0; j < resource; j++){
		printf("%3d类", j + 1);
	}
	printf("        ");
	for (j = 0; j < resource; j++){
		printf("%3d类", j + 1);
	}
	printf("        ");
	for (j = 0; j < resource; j++){
		printf("%3d类", j + 1);
	}
	printf("\n");
	for (i = 0; i < process; i++){
		printf(" P%d      ", i);
		for (j = 0; j < resource; j++){
			printf("%5d", Max[i][j]);
		}
		printf("        ");
		for (j = 0; j < resource; j++){
			printf("%5d", Allocation[i][j]);
		}
		printf("        ");
		for (j = 0; j < resource; j++){
			printf("%5d", Need[i][j]);
		}
		printf("        ");
		if (i == 0){
			for (j = 0; j < resource; j++){
				printf("%5d", Available[j]);
			}
		}
		printf("\n");
	}
}
bool SafeCheck(){
	int i, j;
	int flag = 1;
	int pnum = 0;
	int unpnum = 0;
	int check = 1;
	for (i = 0; i < process; i++){
		if (Available[i] < 0){
			printf("初始化信息有误。\n");
			return false;
		}
	}
	for (i = 0; i < resource; i++){
		Work[i] = Available[i];
	}
	for (i = 0; i < process; i++){
		Finish[i] = false;
	}
	while (flag){
		unpnum = 0;
		flag = 0;                                    //
		for (i = 0; i < process; i++){
			if (Finish[i] == false){
				for (j = 0; j < resource; j++){
					if (Need[i][j] > Work[j]){       //
						check = 0;
						break;
					}
				}
				if (check == 1){
					for (j = 0; j < resource; j++){
						ShowWork[i][j] = Work[j];
						Work[j] += Allocation[i][j];
					}
					Finish[i] = true;
					p[pnum++] = i;
					continue;
				}
			}
			check = 1;
			unpnum++;
		}
		if (unpnum == process){
			printf("安全性检查未通过。");
			for (j = 0; j < pnum; j++){
				printf("-->%d", p[j]);
			}
			return false;
		}
		for (j = 0; j < process; j++){
			if (Finish[j] == false){
				flag = 1;
				break;
			}
		}
	}
	printf("\n             Work              Need              Allocation       Work + Allocation\n");
	printf("          ");
	for (j = 0; j < resource; j++){
		printf("%3d类", j + 1);
	}
	printf("        ");
	for (j = 0; j < resource; j++){
		printf("%3d类", j + 1);
	}
	printf("        ");
	for (j = 0; j < resource; j++){
		printf("%3d类", j + 1);
	}
	printf("        ");
	for (j = 0; j < resource; j++){
		printf("%3d类", j + 1);
	}
	printf("\n");
	for (i = 0; i < process; i++){
		printf(" P%d      ", p[i]);
		for (j = 0; j < resource; j++){
			printf("%5d", ShowWork[p[i]][j]);
		}
		printf("        ");
		for (j = 0; j < resource; j++){
			printf("%5d", Need[p[i]][j]);
		}
		printf("        ");
		for (j = 0; j < resource; j++){
			printf("%5d", Allocation[p[i]][j]);
		}
		printf("        ");
		for (j = 0; j < resource; j++){
			printf("%5d", Allocation[p[i]][j] + ShowWork[p[i]][j]);
		}
		printf("\n");
	}
	printf("安全序列为：");
	for (i = 0; i < process; i++){
		printf("-->%d", p[i]);
	}
	printf("\n");
	return true;
}
void Banker(){
	int i, j;
	int flag = 0;
	int check = 0;
	for (i = 0; i < process; i++){
		if (Available[i] < 0){
			printf("初始化信息有误。\n");
			return;
		}
	}
	printf("\n请输入进程P的编号及Request的值：");
	scanf_s("%d", &i);
	for (j = 0; j < resource; j++){
		scanf_s("%d", &Request[i][j]);
	}
	for (j = 0; j < process; j++){
		if (Request[i][j] > Need[i][j]){
			flag = 1;
			break;
		}
	}
	for (j = 0; j < process; j++){
		if (Request[i][j] > Available[j]){
			flag = 2;
			break;
		}
	}
	if (flag == 0){
		for (j = 0; j < resource; j++){
			Available[j] -= Request[i][j];
			Allocation[i][j] += Request[i][j];
			Need[i][j] -= Request[i][j];
		}
		if (SafeCheck()){
			for (j = 0; j < resource; j++){
				if (Need[i][j] != 0){
					check = 1;
				}
			}
			if (check == 0){
				for (j = 0; j < resource; j++){
					Available[j] = Allocation[i][j];
					Allocation[i][j] = 0;
				}
			}
		}
		else{
			for (j = 0; j < resource; j++){
				Available[j] += Request[i][j];
				Allocation[i][j] -= Request[i][j];
				Need[i][j] += Request[i][j];
			}
		}
	}
	if (flag == 1){
		printf("\nP%d Request > Need, P%d 所需资源大于它宣布的最大值", i, i);
		return;
	}
	if (flag == 2){
		printf("\nP%d Request > Available, 暂无足够资源 P%d 必须等待", i, i);
		return;
	}
}
void main(){
	int choice = 1;
	while (choice)
	{
		Print();
		scanf_s("%d", &choice);
		if (choice == 1)Input();
		if (choice == 2)ShowResource();
		if (choice == 3)SafeCheck();
		if (choice == 4)Banker();
		if (choice == 5)return;
	}
}